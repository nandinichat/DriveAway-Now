from django.apps import AppConfig


class BicycleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bicycle'
