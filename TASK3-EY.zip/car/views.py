from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

def home(request):
  #  return HttpResponse("This is CAR module")
    return render(request, 'index.html')

def registered(request):
    first_name= request.POST['fn']
    last_name= request.POST['ln']
    email= request.POST['email']
    password= request.POST['password']

    person= Registration( first_name=first_name, last_name= last_name, email=email, password=password)
    person.save()
    return render(request, 'registered.html', {'fn': first_name})
